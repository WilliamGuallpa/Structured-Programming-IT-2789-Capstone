package fibonacciNumbers;

import javax.swing.JOptionPane;

public class FibonacciSequence
{

	public FibonacciSequence()
	{
		while (true)
		{
			String userInput;
			
			userInput = startMenu();
			if (userInput.equalsIgnoreCase("calculate"))
			{
				displayFibonacciNumbers(convertFibonacciNumbersToString(calculateFibonacciNumbers()));

			} else if (userInput.equalsIgnoreCase("exit"))
			{
				System.exit(0);
			} else
			{
				invalidInputDisplay();
			}
		}

	}

	public String startMenu()
	{
		String userInput;

		userInput = JOptionPane.showInputDialog(null,
				"Would you like to calculate the first forty five Fibonacci Numbers or exit the program?");

		return userInput;
	}
	

	public long[] calculateFibonacciNumbers()
	{
		int limit = 45;
		long firstTerm = 0;
		long secondTerm = 1;

		long sequence[] = new long[limit];

		for (int i = 0; i < sequence.length; i++)
		{
			sequence[i] = firstTerm + secondTerm;
			
			firstTerm = secondTerm;

			secondTerm = sequence[i];
		}
		return sequence;

	}

	public String convertFibonacciNumbersToString(long[] sequence)
	{
		String numbersList = "";

		for (int i = 0; i < sequence.length; i++)
		{
			numbersList += sequence[i];

			if (i != sequence.length - 1)
			{
				numbersList += ", ";
			}
			if (i % 10 == 0 && i != 0)
			{
				numbersList += "\n";
			}
		}
		return numbersList;
	}

	public void displayFibonacciNumbers(String numbersList)
	{
		JOptionPane.showMessageDialog(null, "The first forty five Fibonacci Numbers are:\n   " + numbersList);
	}

	public void invalidInputDisplay()
	{
		JOptionPane.showMessageDialog(null, "The input is invalid, please try again");
	}

}
